import java.util.*;

public class bbbb {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String name="abcdef 12345";
        String[] bb=new String[2];
        int pos=0;
        for (String t:name.split(" ")){
            bb[pos]=t;
            pos++;
        }
        String n="abcde";
        if (n.equals(bb[0]))
            System.out.println("yes");
        sc.close();
    }
}
