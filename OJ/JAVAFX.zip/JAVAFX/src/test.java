import java.io.*;

public class test {
    public static void main(String[] args) {
        File file =new File("JAVAFX\\chatlog");
        File[] fs=file.listFiles();
        for (File f:fs){
            System.out.println(f);
        }
    }
}